import React from 'react';

function ProjectsPage() {
  return (
    <div>
      ici c'est les projets
    </div>
  );
}

export default ProjectsPage;