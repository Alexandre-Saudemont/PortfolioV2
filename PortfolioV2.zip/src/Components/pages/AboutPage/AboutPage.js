import React from 'react';

function AboutPage() {
  return (
    <div>
      C'est About ici
    </div>
  );
}

export default AboutPage;