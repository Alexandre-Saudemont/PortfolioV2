Hello !

I've decided to upgrade my portfolio and make a V2.0.
I'm a front web developer and like to code with React !

Stack :

- React
- Axios
- Scss
